/**
* Author: Josh Perry
* School: Southen New Hampshire Univesiry
* Course: CS-300
*/

#ifndef COURSE_H
#define COURSE_H

#include <string>
#include <vector>

class Course {
public:
    std::string number;
    std::string name;
    std::vector<std::string> prerequisites;

    Course(std::string num, std::string n, std::vector<std::string> prereqs) : number(num), name(n), prerequisites(prereqs) {}
};

#endif // COURSE_H

/**
* Author: Josh Perry
* School: Southen New Hampshire Univesiry
* Course: CS-300
*/

#ifndef GRAPH_H
#define GRAPH_H

#include "Course.h"
#include <unordered_map>
#include <list>
#include <stack>
#include <iostream>
#include <fstream>
#include <sstream>

class Graph {
private:
    std::unordered_map<std::string, std::list<std::string>> adjList;
    std::unordered_map<std::string, Course*> courses;

    void topologicalSortUtil(const std::string& v, std::unordered_map<std::string, bool>& visited, std::stack<std::string>& Stack) const {
        visited[v] = true;
        // Use .find() to avoid "no operator '[]'" error in const context
        auto it = adjList.find(v);
        if (it != adjList.end()) {
            for (const auto& i : it->second) { // Accessing list of strings
                if (!visited[i]) {
                    topologicalSortUtil(i, visited, Stack);
                }
            }
        }
        Stack.push(v);
    }


public:
    ~Graph() {
        for (auto& pair : courses) {
            delete pair.second;
        }
    }

    void addCourse(Course* course) {
        courses[course->number] = course;
        if (adjList.find(course->number) == adjList.end()) {
            adjList[course->number]; // Ensure the course is in the adjList even if it has no prerequisites.
        }
        for (const auto& prereq : course->prerequisites) {
            adjList[prereq].push_back(course->number);
        }
    }

    void printCourses() const {
        std::stack<std::string> Stack;
        std::unordered_map<std::string, bool> visited;
        for (auto& i : adjList) {
            if (!visited[i.first]) {
                topologicalSortUtil(i.first, visited, Stack);
            }
        }

        while (!Stack.empty()) {
            std::string courseNumber = Stack.top();
            Stack.pop();
            if (courses.find(courseNumber) != courses.end()) {
                std::cout << courses.at(courseNumber)->number << ", " << courses.at(courseNumber)->name << std::endl;
            }
        }
    }

    // Implement readFileToDataStructure and other functions as needed.
};

#endif // GRAPH

/**
* Author: Josh Perry
* School: Southen New Hampshire Univesiry
* Course: CS-300
*/

#include "Graph.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

// Function to read course data from a file and load it into the graph
void readFileToDataStructure(const std::string& filename, Graph& graph) {
    std::ifstream file(filename);
    if (!file) {
        std::cerr << "Error: File '" << filename << "' could not be opened." << std::endl;
        return;
    }

    std::string line;
    while (getline(file, line)) {
        std::istringstream iss(line);
        std::string number, name;
        std::vector<std::string> prerequisites;
        getline(iss, number, ',');
        getline(iss, name, ',');
        std::string token;
        while (getline(iss, token, ',')) {
            prerequisites.push_back(token);
        }
        Course* course = new Course(number, name, prerequisites);
        graph.addCourse(course);
    }
    std::cout << "Data loaded successfully.\n";
}

int main() {
    Graph graph;
    std::string choice;

    // Main program loop for user interaction
    while (true) {
        std::cout << "1. Load Data Structure\n2. Print Course List\n3. Exit\nEnter your choice: ";
        std::cin >> choice;

        if (choice == "1") {
            std::cout << "Enter filename: ";
            std::string filename;
            std::cin >> filename;
            readFileToDataStructure(filename, graph);
        }
        else if (choice == "2") {
            graph.printCourses();
        }
        else if (choice == "3") {
            std::cout << "Exiting program." << std::endl;
            break;
        }
        else {
            std::cout << "Invalid input, please try again." << std::endl;
        }
    }

    return 0;
}

